/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.abc.finalsolution;

import java.util.Scanner;

/**
 *
 * @author B11
 */
public class Test {
    public static void main(String[] args) {
        
    }
    
    public void getmaxmin(){
    Scanner = new Scanner(System.in);
    int a = scanner.nextInt(),
    int b = scanner.nextInt(),
    int c = scanner.nextInt(),
            
            String input = scanner.nextInt();
            String[] numbers = input.split(",");
    
    
    }
}
