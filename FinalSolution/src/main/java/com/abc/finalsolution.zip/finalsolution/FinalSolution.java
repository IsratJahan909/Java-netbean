/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.abc.finalsolution;

/**
 *
 * @author B11
 */
public class FinalSolution {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
