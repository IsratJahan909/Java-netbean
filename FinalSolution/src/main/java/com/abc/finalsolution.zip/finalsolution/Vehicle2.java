/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.abc.finalsolution;

/**
 *
 * @author B11
 */
public class Vehicle2 {

    double regularPrice;
    String color;

    Vehicle2(double regularPrice, String color) {
        this.regularPrice = regularPrice;
        this.color = color;
    }

    public double getPurchasePrice() {
        return regularPrice;
    }
}
