///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package com.abc.finalsolution;
//
//import java.util.Arrays;
//import static java.util.Arrays.deepToString;
//
//public class DimensionArray {
//
//    public static void main(String[] args) {
//        int[][] arr = {
//            {1, 99, 91, 11, 44},
//            {0, 20, 9, 9, 11},
//            {3, 23, 21, 5, 20},
//            {13, 4, 45, 66, 33},
//            {11, 0, 1, 20, 56}
//        };
//        
//        
//        
//        for(Integer[] i : array2d){
//        bubbleSort(i);
//        arrayPrint(i);
//        }
//        System.out.println();
//        System.out.println(" " + Arrays.deepToString(arr));
//    }
//
//    public static void bubbleSort(int[] arr) {
//        int n = arr.length;
//        for (int i = 0; i < n - 1; i++) {
//            for (int j = 0; j < n - 1 - i; j++) {
//                if (arr[j] > arr[j + 1]) {
//                    int temp = arr[j];
//                    arr[j] = arr[j + 1];
//                    arr[j + 1] = temp;
//                }
//
//            }
//
//        }
//
//    }
//}
